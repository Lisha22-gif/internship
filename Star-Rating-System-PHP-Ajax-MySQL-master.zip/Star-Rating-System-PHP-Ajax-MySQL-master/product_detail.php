
<?php
$title = 'Star Rating System with Ajax, PHP and MySQL';
$content = "inc/product_detail_content.php";
include "layout/app.php";
?>
